"""
FreeFuse Phase 1 Sampler

Runs partial denoising to collect attention patterns and generate masks.
After this node, use standard KSampler for Phase 2 generation.

Uses ComfyUI's replace patch mechanism to intercept attention internals.
"""

import torch
import torch.nn.functional as F
import os
import json
import comfy.samplers
import comfy.sample

from ..freefuse_core.attention_replace import (
    FreeFuseState,
    FreeFuseFluxBlockReplace,
    FreeFuseSDXLAttnReplace,
    FreeFuseZImageBlockReplace,
    apply_freefuse_replace_patches,
    compute_flux_similarity_maps_from_outputs,
    compute_z_image_similarity_maps,
)
from ..freefuse_core.krea2_support import apply_krea2_replace_patches
from ..freefuse_core.mask_utils import generate_masks
from ..freefuse_core.tensor_debug import format_tensor_stats, tensor_scalar_to_float
from ..freefuse_core.token_utils import detect_model_type
from ..freefuse_core.voting import create_consensus_similarity_maps

# SDXL UNet region → ComfyUI (block_name, block_num) mapping
# Each region contains N transformer blocks with cross-attention (attn2).
# The user picks a region + transformer index to select which attn2 to collect from.
SDXL_COLLECT_REGION_MAP = {
    "output_early ★ (recommended)": ("output", 0, 10),   # output_blocks.0, 10 transformers
    "output_mid":                    ("output", 1, 10),   # output_blocks.1, 10 transformers
    "output_late":                   ("output", 2, 10),   # output_blocks.2, 10 transformers
    "middle":                        ("middle", 0, 10),   # middle_block,    10 transformers
    "input_deep":                    ("input",  7, 10),   # input_blocks.7,  10 transformers
    "input_deep_2":                  ("input",  8, 10),   # input_blocks.8,  10 transformers
    "output_shallow":                ("output", 3,  2),   # output_blocks.3,  2 transformers
    "input_shallow":                 ("input",  4,  2),   # input_blocks.4,   2 transformers
}


class EarlyStopException(Exception):
    """Exception to signal early termination of sampling after mask collection."""
    pass


class FreeFusePhase1Sampler:
    """
    Phase 1: Collect similarity maps and generate spatial masks.
    
    Runs a few denoising steps (default 5) to collect attention patterns,
    then generates masks for each LoRA concept.
    
    Output the patched model to standard KSampler for Phase 2.
    """
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": ("MODEL",),
                "conditioning": ("CONDITIONING",),
                "neg_conditioning": ("CONDITIONING",),
                "latent": ("LATENT",),
                "freefuse_data": ("FREEFUSE_DATA",),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xffffffffffffffff}),
                "steps": ("INT", {"default": 28, "min": 1, "max": 150, 
                    "tooltip": "Total steps for sigma schedule (should match Phase 2)"}),
                "collect_step": ("INT", {"default": 5, "min": 1, "max": 20,
                    "tooltip": "Step at which to collect attention and stop Phase 1"}),
                "cfg": ("FLOAT", {"default": 3.5, "min": 0.0, "max": 20.0, "step": 0.1}),
                "sampler_name": (comfy.samplers.KSampler.SAMPLERS,),
                "scheduler": (comfy.samplers.KSampler.SCHEDULERS,),
            },
            "optional": {
                "sigmas": ("SIGMAS",),
                # Block selection — Flux
                "collect_block": ("INT", {
                    "default": 18, "min": 0, "max": 56,
                    "tooltip": "[Flux/Flux2/Z-Image/Krea2 only] Flux uses transformer_blocks.<idx>; Flux2 uses single_transformer_blocks.<idx>; Z-Image uses layers.<idx>; Krea2 uses blocks.<idx> (0-27). Ignored for SDXL."
                }),
                "collect_block_end": ("INT", {
                    "default": 18, "min": 0, "max": 56,
                    "tooltip": "[Flux/Flux2/Z-Image/Krea2 only] Optional end block (inclusive). If > collect_block, collect a range and aggregate by majority voting."
                }),
                # Block selection — SDXL
                "collect_region": (list(SDXL_COLLECT_REGION_MAP.keys()), {
                    "default": "output_early ★ (recommended)",
                    "tooltip": "[SDXL only] UNet region to collect cross-attention from. Ignored for Flux."
                }),
                "collect_tf_index": ("INT", {
                    "default": 3, "min": 0, "max": 9,
                    "tooltip": "[SDXL only] Transformer block index within the selected region (0-9). Ignored for Flux."
                }),
                # Similarity map computation parameters
                "temperature": ("FLOAT", {
                    "default": 0.0, "min": 0.0, "max": 10000.0, "step": 100.0,
                    "tooltip": "Temperature for softmax in similarity computation. 0=auto (Flux:4000, SDXL:300)"
                }),
                "top_k_ratio": ("FLOAT", {
                    "default": 0.3, "min": 0.01, "max": 1.0, "step": 0.05,
                    "tooltip": "Ratio of top-k tokens to use for similarity computation"
                }),
                # LoRA control
                "disable_lora_phase1": ("BOOLEAN", {
                    "default": True,
                    "tooltip": "Disable LoRA during Phase 1 for cleaner base model attention (recommended)"
                }),
                # Mask post-processing parameters
                "bg_scale": ("FLOAT", {
                    "default": 0.95, "min": 0.0, "max": 2.0, "step": 0.05,
                    "tooltip": "Scale factor for background similarity (higher = more background)"
                }),
                "use_morphological_cleaning": ("BOOLEAN", {
                    "default": False,
                    "tooltip": "Apply morphological operations to clean up masks"
                }),
                "balance_iterations": ("INT", {
                    "default": 15, "min": 0, "max": 50,
                    "tooltip": "Number of iterations for balanced argmax algorithm"
                }),
                # stabilized_balanced_argmax fine-tuning parameters
                "balance_lr": ("FLOAT", {
                    "default": 0.01, "min": 0.001, "max": 0.1, "step": 0.001,
                    "tooltip": "Learning rate for bias updates in mask balancing (higher = faster convergence but may overshoot)"
                }),
                "gravity_weight": ("FLOAT", {
                    "default": 0.00004, "min": 0.0, "max": 1.0, "step": 0.00001,
                    "tooltip": "Centroid attraction weight - pulls pixels toward their concept's center for spatial coherence"
                }),
                "spatial_weight": ("FLOAT", {
                    "default": 0.00004, "min": 0.0, "max": 1.0, "step": 0.00001,
                    "tooltip": "Neighbor voting weight - encourages spatially smooth masks by considering neighboring pixels"
                }),
                "momentum": ("FLOAT", {
                    "default": 0.2, "min": 0.0, "max": 0.9, "step": 0.05,
                    "tooltip": "Probability smoothing momentum between iterations (higher = more stable but slower adaptation)"
                }),
                "centroid_margin": ("FLOAT", {
                    "default": 0.0, "min": 0.0, "max": 0.5, "step": 0.05,
                    "tooltip": "Margin to clamp centroids away from image borders (0 = no clamping)"
                }),
                "border_penalty": ("FLOAT", {
                    "default": 0.0, "min": 0.0, "max": 1.0, "step": 0.01,
                    "tooltip": "Penalty for assigning concept pixels near image borders (0 = no penalty)"
                }),
                "anisotropy": ("FLOAT", {
                    "default": 1.3, "min": 0.5, "max": 3.0, "step": 0.1,
                    "tooltip": "Horizontal stretch factor for spatial coordinates (>1 = prefer wider masks, <1 = prefer taller masks)"
                }),
            }
        }
    
    RETURN_TYPES = ("MODEL", "FREEFUSE_MASKS", "IMAGE")
    RETURN_NAMES = ("model", "masks", "mask_preview")
    FUNCTION = "collect_masks"
    CATEGORY = "FreeFuse"
    
    DESCRIPTION = """Phase 1 of FreeFuse: collect attention and generate masks.
    
Uses full sigma schedule (e.g., 28 steps) but stops early after collecting
attention at collect_step. This ensures correct noise levels while saving time.

Block Selection (model-type aware):
- Flux: Use 'collect_block' (INT 0-56) to pick transformer_blocks.<idx>.
- Flux: Set 'collect_block_end' > 'collect_block' to aggregate a block range.
- Flux2: Use 'collect_block' (INT 0-56) to pick single_transformer_blocks.<idx>.
- Flux2: Set 'collect_block_end' > 'collect_block' to aggregate a block range.
- Z-Image: Use 'collect_block' (INT 0-56) to pick layers.<idx>.
- Z-Image: Set 'collect_block_end' > 'collect_block' to aggregate a block range.
- SDXL: Use 'collect_region' + 'collect_tf_index' to pick a UNet cross-attention block.
  The recommended default is output_early (region) + 3 (tf_index).
  Other parameters for the non-active model type are simply ignored.

Other Parameters:
- temperature: Softmax temperature for similarity (0=auto-detect by model type)
- top_k_ratio: Ratio of tokens used for similarity computation
- disable_lora_phase1: Whether to disable LoRA during collection (recommended)
- bg_scale: Background scaling factor for mask generation
- use_morphological_cleaning: Clean up masks with morphological operations

Mask Balancing Parameters (Advanced):
- balance_iterations: Number of iterations for the balanced argmax algorithm
- balance_lr: Learning rate for bias updates (higher = faster but less stable)
- gravity_weight: Centroid attraction for spatial coherence
- spatial_weight: Neighbor voting for spatially smooth masks
- momentum: Probability smoothing between iterations
- centroid_margin: Clamp centroids away from borders
- border_penalty: Penalize concept assignment near borders
- anisotropy: Horizontal stretch factor (>1 prefers wider masks)

After this node, connect the model output to a standard KSampler
for Phase 2 generation with the same seed and steps."""
    
    def collect_masks(self, model, conditioning, neg_conditioning, latent,
                      freefuse_data, seed, steps, collect_step, cfg, sampler_name, scheduler,
                      collect_block=18, collect_block_end=18,
                      collect_region="output_early ★ (recommended)", collect_tf_index=3,
                      temperature=0.0, top_k_ratio=0.3,
                      disable_lora_phase1=True, bg_scale=0.95, 
                      use_morphological_cleaning=True, balance_iterations=15,
                      balance_lr=0.01, gravity_weight=0.00004, spatial_weight=0.00004,
                      momentum=0.2, centroid_margin=0.0, border_penalty=0.0,
                      anisotropy=1.3, sigmas=None):
        
        concepts = freefuse_data.get("concepts", {})
        settings = freefuse_data.get("settings", {})
        token_pos_maps = freefuse_data.get("token_pos_maps", {})
        include_background = settings.get("enable_background", True)
        
        if not concepts:
            print("[FreeFuse] Warning: No concepts defined, returning empty masks")
            empty_masks = {}
            preview = torch.zeros(1, 64, 64, 3)
            return (model, {"masks": empty_masks}, preview)
        
        # Check if token positions are available
        if not token_pos_maps:
            print("[FreeFuse] Warning: No token positions computed. "
                  "Connect FreeFuseTokenPositions node before this sampler.")
            # Create fallback uniform masks
            latent_image = latent["samples"]
            latent_h, latent_w = latent_image.shape[2], latent_image.shape[3]
            img_h, img_w = self._latent_to_image_size(model, latent_h, latent_w)
            
            masks = {name: torch.ones(latent_h, latent_w) for name in concepts}
            preview = self._create_preview(masks, img_w, img_h)
            return (model, {"masks": masks}, preview)
        
        # Clone model to add attention hooks
        model_clone = model.clone()
        
        # Sanity check: collect_step must be within total steps
        if collect_step > steps:
            print(f"[FreeFuse] Warning: collect_step ({collect_step}) > steps ({steps}); "
                  f"clamping to {steps}.")
            collect_step = steps
        if collect_step < 1:
            print(f"[FreeFuse] Warning: collect_step ({collect_step}) < 1; "
                  "clamping to 1.")
            collect_step = 1

        # Set up FreeFuse state with the new system
        freefuse_state = FreeFuseState()
        freefuse_state.phase = "collect"
        # Collect at the specified step (0-indexed internally)
        freefuse_state.collect_step = collect_step - 1  # Convert to 0-indexed
        freefuse_state.collect_block = collect_block  # Used by Flux
        freefuse_state.collect_block_end = collect_block_end
        freefuse_state.token_pos_maps = token_pos_maps
        freefuse_state.include_background = include_background
        
        # Detect model type first (needed for default temperature and block routing).
        model_type = detect_model_type(
            model=model_clone,
            model_type_hint=freefuse_data.get("model_type"),
        )
        if model_type == "unknown":
            model_type = "sdxl"

        # Internal patch route aliases.
        if model_type == "qwen3":
            patch_model_type = "z_image"
        else:
            patch_model_type = model_type
        
        # Use user-provided parameters, with auto-detection for temperature=0
        # Default temperature differs by model type: Flux=4000, SDXL=300, Z-Image=4000
        if temperature == 0.0:
            if patch_model_type == "z_image":
                auto_temperature = 4000.0   # matches reference FreeFuseZImageAttnProcessor
            elif patch_model_type in ("flux", "flux2"):
                auto_temperature = 4000.0
            elif patch_model_type == "krea2":
                auto_temperature = 4000.0   # single-stream, RoPE+QK-norm attn like Z-Image; tune later
            else:
                auto_temperature = 300.0
        else:
            auto_temperature = temperature
        
        freefuse_state.top_k_ratio = top_k_ratio
        freefuse_state.temperature = auto_temperature
        
        # Build SDXL collect_blocks from region + tf_index (only used for SDXL)
        sdxl_collect_blocks = None
        flux_collect_blocks = None
        flux2_collect_blocks = None
        z_image_collect_blocks = None
        range_collect_blocks = None
        if patch_model_type == "sdxl":
            region_info = SDXL_COLLECT_REGION_MAP.get(collect_region)
            if region_info is None:
                # Fallback to recommended default
                print(f"[FreeFuse] Warning: Unknown region '{collect_region}', using default")
                region_info = ("output", 0, 10)
            block_name, block_num, max_tf = region_info
            # Clamp tf_index to valid range for this region
            tf_idx = min(collect_tf_index, max_tf - 1)
            if tf_idx != collect_tf_index:
                print(f"[FreeFuse] Warning: collect_tf_index={collect_tf_index} clamped to {tf_idx} "
                      f"(region '{collect_region}' has {max_tf} transformers)")
            sdxl_collect_blocks = [(block_name, block_num, tf_idx)]
            print(f"[FreeFuse] SDXL collect block: ({block_name}, {block_num}, {tf_idx}) "
                  f"from region='{collect_region}'")
        elif patch_model_type in ("flux", "flux2", "z_image", "krea2"):
            range_start = int(collect_block)
            range_end = int(collect_block_end)
            if range_end < range_start:
                print(
                    f"[FreeFuse] Warning: collect_block_end ({range_end}) < collect_block ({range_start}); "
                    f"using single block {range_start}."
                )
                range_end = range_start
            freefuse_state.collect_block = range_start
            freefuse_state.collect_block_end = range_end
            if range_end > range_start:
                range_collect_blocks = list(range(range_start, range_end + 1))
                if patch_model_type == "flux":
                    flux_collect_blocks = range_collect_blocks
                elif patch_model_type == "flux2":
                    flux2_collect_blocks = range_collect_blocks
                elif patch_model_type == "z_image":
                    z_image_collect_blocks = range_collect_blocks
                # krea2 uses range_collect_blocks directly (see apply_krea2_replace_patches call below)
                print(
                    f"[FreeFuse] {patch_model_type} range mode: collecting blocks {range_start}-{range_end} "
                    f"({len(range_collect_blocks)} blocks)"
                )
        elif collect_block_end != collect_block:
            # Keep SDXL behavior stable.
            print(
                f"[FreeFuse] Info: collect_block_end is ignored for {patch_model_type}; "
                f"using collect_block={collect_block}."
            )
            
        krea2_replacer = None
        if patch_model_type == "krea2":
            krea2_replacer = apply_krea2_replace_patches(
                model_clone, freefuse_state,
                krea2_collect_blocks=range_collect_blocks,  # None means use [state.collect_block]
            )
        else:
            apply_freefuse_replace_patches(
                model_clone, freefuse_state,
                model_type=patch_model_type,
                sdxl_collect_blocks=sdxl_collect_blocks,
                flux_collect_blocks=flux_collect_blocks,
                flux2_collect_blocks=flux2_collect_blocks,
                z_image_collect_blocks=z_image_collect_blocks,
            )
        
        # Get latent info
        latent_image = latent["samples"]
        batch_size = latent_image.shape[0]
        
        # Calculate image dimensions
        latent_h, latent_w = latent_image.shape[2], latent_image.shape[3]
        img_h, img_w = self._latent_to_image_size(model_clone, latent_h, latent_w)

        # For Flux2 single-stream extraction, cache img sequence length for txt_len resolution.
        if patch_model_type == "flux2":
            freefuse_state.collected_outputs["img_seq_len"] = latent_h * latent_w
        
        # For Z-Image: store sequence lengths in state so block_replace can access them
        if patch_model_type == "z_image":
            z_img_seq_len = latent_h * latent_w
            # Estimate cap_seq_len from token positions map
            z_cap_seq_len = 256  # Default
            for positions_list in token_pos_maps.values():
                if positions_list and positions_list[0]:
                    max_pos = max(positions_list[0])
                    z_cap_seq_len = max(z_cap_seq_len, max_pos + 10)
            freefuse_state.collected_outputs["img_seq_len"] = z_img_seq_len
            freefuse_state.collected_outputs["cap_seq_len"] = z_cap_seq_len
            freefuse_state.collected_outputs["latent_h"] = latent_h
            freefuse_state.collected_outputs["latent_w"] = latent_w
            print(f"[FreeFuse] Z-Image sequence info: img_seq_len={z_img_seq_len}, cap_seq_len={z_cap_seq_len}")
        
        block_info = (
            (
                f"double_block {collect_block}-{collect_block_end}"
                if (patch_model_type == "flux" and range_collect_blocks is not None)
                else f"double_block {collect_block}"
            )
            if patch_model_type == "flux"
            else (
                (
                    f"single_transformer_blocks.{collect_block}-{collect_block_end}"
                    if (patch_model_type == "flux2" and range_collect_blocks is not None)
                    else f"single_transformer_blocks.{collect_block}"
                )
                if patch_model_type == "flux2"
                else (
                    (
                        f"layer {collect_block}-{collect_block_end}"
                        if (patch_model_type == "z_image" and range_collect_blocks is not None)
                        else f"layer {collect_block}"
                    )
                    if patch_model_type == "z_image"
                    else (
                        (
                            f"blocks.{collect_block}-{collect_block_end}"
                            if (patch_model_type == "krea2" and range_collect_blocks is not None)
                            else f"blocks.{collect_block}"
                        )
                        if patch_model_type == "krea2"
                        else f"{collect_region} tf={collect_tf_index}"
                    )
                )
            )
        )
        print(f"[FreeFuse] Phase 1: {steps} total steps, collecting at step {collect_step}, {block_info}")
        print(f"[FreeFuse] Concepts: {list(concepts.keys())}")
        print(f"[FreeFuse] Token positions: {token_pos_maps}")
        print(f"[FreeFuse] Model type: {model_type} (patch route: {patch_model_type})")
        print(f"[FreeFuse] Settings: temperature={auto_temperature}, top_k_ratio={top_k_ratio}, disable_lora={disable_lora_phase1}")
        
        # Optionally disable LoRA during Phase 1 to get clean base model attention patterns
        # This matches the diffusers implementation behavior
        bypass_manager = model_clone.model_options.get("transformer_options", {}).get("freefuse_bypass_manager")
        if bypass_manager is not None and disable_lora_phase1:
            bypass_manager.disable_lora()
            print("[FreeFuse] Phase 1: LoRA disabled for clean attention collection")
        elif bypass_manager is not None:
            print("[FreeFuse] Phase 1: LoRA enabled (user override)")
        
        # Create noise for Phase 1
        noise = comfy.sample.prepare_noise(latent_image, seed, None)
        
        # Configure step callback to update current step and enable early stopping
        def step_callback(step, x0, x, total_steps):
            freefuse_state.current_step = step
            # Check if we've collected similarity maps and can stop early
            if step <= freefuse_state.collect_step or not freefuse_state.similarity_maps:
                return

            if range_collect_blocks and len(range_collect_blocks) > 1:
                collected = len(freefuse_state.collected_blocks)
                expected = len(range_collect_blocks)
                if collected >= expected:
                    print(
                        f"[FreeFuse] Early stopping at step {step + 1} "
                        f"(range collected {collected}/{expected} blocks at step {collect_step}, "
                        f"model={patch_model_type})"
                    )
                    raise EarlyStopException("Range similarity maps collected, stopping early")
                if step > freefuse_state.collect_step + 1:
                    print(
                        f"[FreeFuse] Warning: only {collected}/{expected} range blocks collected; "
                        f"stopping early with available blocks."
                    )
                    raise EarlyStopException("Partial range maps collected, stopping early")
                return

            print(f"[FreeFuse] Early stopping at step {step + 1} (collected at step {collect_step})")
            raise EarlyStopException("Similarity maps collected, stopping early")
        
        # Run Phase 1 sampling (may terminate early via EarlyStopException)
        early_stopped = False
        try:
            samples = comfy.sample.sample(
                model_clone,
                noise,
                steps,
                cfg,
                sampler_name,
                scheduler,
                conditioning,
                neg_conditioning,
                latent_image,
                denoise=1.0,
                disable_noise=False,
                start_step=0,
                last_step=steps,
                force_full_denoise=False,
                noise_mask=None,
                sigmas=sigmas,
                callback=step_callback,
                seed=seed,
            )
        except EarlyStopException as e:
            # Expected early termination - similarity maps already collected
            early_stopped = True
            print(f"[FreeFuse] Phase 1 completed early: {e}")
        except Exception as e:
            print(f"[FreeFuse] Phase 1 sampling error: {e}")
            import traceback
            traceback.print_exc()
            # Re-enable LoRA before returning on error (if it was disabled)
            if bypass_manager is not None and disable_lora_phase1:
                bypass_manager.enable_lora()
            if patch_model_type == "krea2":
                raise RuntimeError(
                    "[FreeFuse Krea2] Phase 1 failed before collecting valid masks"
                ) from e
            # Return empty masks on error
            empty_masks = {name: torch.ones(latent_h, latent_w) for name in concepts}
            preview = self._create_preview(empty_masks, img_w, img_h)
            return (model_clone, {"masks": empty_masks}, preview)
        finally:
            # Krea2 uses raw torch hooks (no ComfyUI patch-dict lifecycle), so they
            # must be removed explicitly or they accumulate on the shared module
            # across repeated Phase-1 runs.
            if krea2_replacer is not None:
                krea2_replacer.remove()
                print("[FreeFuse Krea2] Removed Phase-1 collection hooks")
        
        # Get similarity maps directly from freefuse_state
        similarity_maps = freefuse_state.similarity_maps

        # Optional range-mode aggregation for Flux / Flux2 / Z-Image.
        if range_collect_blocks and len(range_collect_blocks) > 1:
            block_sim_maps = freefuse_state.collected_outputs.get("block_similarity_maps", {})
            if block_sim_maps:
                print(
                    f"[FreeFuse] Range mode collected block ids: "
                    f"{sorted(int(k) for k in block_sim_maps.keys())}"
                )
                concept_names = []
                seen = set()
                # Prefer concept-map ordering when present.
                for name in token_pos_maps.keys():
                    for _, per_block in block_sim_maps.items():
                        if name in per_block and name not in seen:
                            concept_names.append(name)
                            seen.add(name)
                            break
                # Add any extra keys found in collected maps.
                for _, per_block in block_sim_maps.items():
                    for name in per_block.keys():
                        if name not in seen:
                            concept_names.append(name)
                            seen.add(name)

                vote_h, vote_w, vote_len = self._resolve_range_voting_size(
                    block_sim_maps=block_sim_maps,
                    concept_names=concept_names,
                    latent_h=latent_h,
                    latent_w=latent_w,
                )
                if (vote_h * vote_w) != (latent_h * latent_w):
                    print(
                        f"[FreeFuse] Range mode voting size resolved to {vote_h}x{vote_w} "
                        f"(len={vote_len}) from latent {latent_h}x{latent_w}."
                    )

                voted_maps = create_consensus_similarity_maps(
                    all_blocks_similarity_maps=block_sim_maps,
                    concept_names=concept_names,
                    latent_h=vote_h,
                    latent_w=vote_w,
                    device=latent_image.device,
                )
                if voted_maps and self._has_similarity_signal(voted_maps):
                    similarity_maps = voted_maps
                    freefuse_state.similarity_maps = voted_maps
                    print(
                        f"[FreeFuse] Range mode voting aggregated {len(block_sim_maps)} blocks "
                        f"into {len(voted_maps)} concept maps (model={patch_model_type})."
                    )
                else:
                    print(
                        f"[FreeFuse] Warning: range voting produced degenerate maps "
                        f"(all-zero or empty). Falling back to last collected block maps. "
                        f"(blocks_collected={len(block_sim_maps)}, model={patch_model_type})"
                    )
                    self._log_range_block_debug(
                        block_sim_maps=block_sim_maps,
                        concept_names=concept_names,
                        expected_img_len=vote_len,
                    )
            else:
                print(
                    f"[FreeFuse] Warning: range mode enabled but no per-block maps were collected "
                    f"(model={patch_model_type})."
                )

        # Optional debug dump for Z-Image
        if os.environ.get("FREEFUSE_DEBUG_ZIMAGE") == "1" and patch_model_type == "z_image":
            debug_dir = os.path.join(os.getcwd(), "debug_z_image_comfyui")
            os.makedirs(debug_dir, exist_ok=True)
            try:
                # Save token positions + concepts
                debug_meta = {
                    "concepts": concepts,
                    "token_pos_maps": token_pos_maps,
                    "collect_block": collect_block,
                    "collect_block_end": collect_block_end,
                    "collect_step": collect_step,
                    "top_k_ratio": top_k_ratio,
                    "temperature": auto_temperature,
                }
                with open(os.path.join(debug_dir, "phase1_meta.json"), "w", encoding="utf-8") as f:
                    json.dump(debug_meta, f, ensure_ascii=False, indent=2)
                # Save similarity maps
                if similarity_maps:
                    sim_cpu = {k: v.detach().cpu() for k, v in similarity_maps.items()}
                    torch.save(sim_cpu, os.path.join(debug_dir, "similarity_maps.pt"))
            except Exception as e:
                print(f"[FreeFuse Z-Image Debug] Failed to save debug artifacts: {e}")
        
        # Debug: Show raw similarity maps
        print(f"[FreeFuse] Raw similarity maps: {list(similarity_maps.keys())}")
        for name, sim_map in similarity_maps.items():
            if sim_map is not None:
                print(f"   {name}: {format_tensor_stats(sim_map, include_shape=True, include_mean=True)}")
        
        # Generate masks directly from raw similarity maps
        # The new generate_masks can handle (B, N, 1) format and includes:
        # - stabilized_balanced_argmax from diffusers
        # - morphological cleaning
        # - proper background handling
        if similarity_maps:
            masks = generate_masks(
                similarity_maps, 
                include_background=include_background,  # Use setting from concept map
                method="stabilized",  # Use the sophisticated algorithm from diffusers
                bg_scale=bg_scale,  # User-configurable background scale
                use_morphological_cleaning=use_morphological_cleaning,  # User-configurable
                debug=True,  # Enable debug output
                max_iter=balance_iterations,  # User-configurable iterations
                latent_h=latent_h,  # CRITICAL: Pass latent dimensions for correct reshape!
                latent_w=latent_w,  # Without this, non-square images produce corrupted masks!
                # stabilized_balanced_argmax fine-tuning parameters
                balance_lr=balance_lr,
                gravity_weight=gravity_weight,
                spatial_weight=spatial_weight,
                momentum=momentum,
                centroid_margin=centroid_margin,
                border_penalty=border_penalty,
                anisotropy=anisotropy,
            )
        else:
            if patch_model_type == "krea2":
                raise RuntimeError(
                    "[FreeFuse Krea2] Phase 1 produced no similarity maps; "
                    "refusing to create uniform masks."
                )
            # Fallback: create uniform masks
            print("[FreeFuse] Warning: No similarity maps, using uniform masks")
            masks = {}
            for name in concepts.keys():
                masks[name] = torch.ones(latent_h, latent_w, device=latent_image.device)
            if include_background:
                masks["_background_"] = torch.zeros(latent_h, latent_w, device=latent_image.device)

        # Optional debug dump for masks
        if os.environ.get("FREEFUSE_DEBUG_ZIMAGE") == "1" and patch_model_type == "z_image":
            try:
                debug_dir = os.path.join(os.getcwd(), "debug_z_image_comfyui")
                os.makedirs(debug_dir, exist_ok=True)
                mask_cpu = {k: v.detach().cpu() for k, v in masks.items()}
                torch.save(mask_cpu, os.path.join(debug_dir, "masks.pt"))
            except Exception as e:
                print(f"[FreeFuse Z-Image Debug] Failed to save masks: {e}")
        
        # Create preview image
        preview = self._create_preview(masks, img_w, img_h)
        
        # Update state for Phase 2
        freefuse_state.phase = "generate"
        freefuse_state.masks = masks
        
        # Re-enable LoRA for Phase 2 generation (if it was disabled)
        if bypass_manager is not None and disable_lora_phase1:
            bypass_manager.enable_lora()
            print("[FreeFuse] Phase 1 complete: LoRA re-enabled for Phase 2")
        
        # Store masks in model options for Phase 2
        if "transformer_options" not in model_clone.model_options:
            model_clone.model_options["transformer_options"] = {}
        model_clone.model_options["transformer_options"]["freefuse_masks"] = masks
        model_clone.model_options["freefuse_state"] = freefuse_state
        
        print(f"[FreeFuse] Phase 1 complete. Generated {len(masks)} masks.")
        print(f"[FreeFuse] Mask keys: {list(masks.keys())}")
        for name, mask in masks.items():
            coverage = tensor_scalar_to_float(mask.sum()) / mask.numel() * 100
            print(f"   {name}: coverage={coverage:.1f}%")
        
        try:
            phase1_seed = int(seed)
        except Exception:
            phase1_seed = seed
        mask_bank = {
            "masks": masks,
            "similarity_maps": similarity_maps,
            "metadata": {
                "phase1_seed": phase1_seed,
            },
        }
        return (
            model_clone,
            mask_bank,
            preview
        )

    @staticmethod
    def _get_latent_downscale_ratio(model_patcher, fallback_ratio: int = 8) -> int:
        """Resolve latent->image downscale ratio from model latent_format."""
        latent_format = None
        try:
            latent_format = model_patcher.get_model_object("latent_format")
        except Exception:
            latent_format = getattr(getattr(model_patcher, "model", None), "latent_format", None)

        ratio = getattr(latent_format, "spacial_downscale_ratio", fallback_ratio)
        try:
            ratio = int(ratio)
            if ratio > 0:
                return ratio
        except Exception:
            pass
        return fallback_ratio

    @classmethod
    def _latent_to_image_size(cls, model_patcher, latent_h: int, latent_w: int) -> tuple:
        ratio = cls._get_latent_downscale_ratio(model_patcher)
        return latent_h * ratio, latent_w * ratio
    
    @staticmethod
    def _infer_spatial_size_from_latent(
        seq_len: int, lat_h: int, lat_w: int
    ) -> tuple:
        """Infer (h, w) from a flattened sequence length using latent aspect ratio.

        Tries power-of-2 downscale factors first, then aspect-ratio-preserving
        factorisation, then square, and finally a generic closest-to-square search.
        """
        # Strategy 1: power-of-2 downscale factors of latent_size
        for d in (1, 2, 4, 8, 16):
            h, w = lat_h // d, lat_w // d
            if h > 0 and w > 0 and h * w == seq_len:
                return (h, w)

        # Strategy 2: aspect-ratio-preserving decomposition
        if lat_h > 0 and lat_w > 0:
            ratio = lat_w / lat_h
            h = max(int(round((seq_len / max(ratio, 1e-8)) ** 0.5)), 1)
            w = seq_len // h
            if h * w == seq_len:
                return (h, w)

        # Strategy 3: square
        side = int(round(seq_len ** 0.5))
        if side * side == seq_len:
            return (side, side)

        # Strategy 4: closest-to-square factor search
        import math as _math
        best_h, best_w = 1, seq_len
        for h in range(1, int(_math.isqrt(seq_len)) + 1):
            if seq_len % h == 0:
                w = seq_len // h
                if abs(w - h) < abs(best_w - best_h):
                    best_h, best_w = h, w
        return (best_h, best_w)

    @staticmethod
    def _has_similarity_signal(similarity_maps: dict) -> bool:
        """Return True if any similarity map contains positive finite values."""
        if not similarity_maps:
            return False
        for sim_map in similarity_maps.values():
            if not torch.is_tensor(sim_map):
                continue
            if sim_map.numel() == 0:
                continue
            finite = torch.isfinite(sim_map)
            if torch.any(finite & (sim_map > 0)):
                return True
        return False

    @staticmethod
    def _log_range_block_debug(
        block_sim_maps: dict,
        concept_names: list,
        expected_img_len: int,
    ) -> None:
        """Print per-block key/shape/value summaries for range-voting diagnostics."""
        try:
            for block_idx in sorted(block_sim_maps.keys()):
                per_block = block_sim_maps.get(block_idx, {})
                if not isinstance(per_block, dict):
                    print(f"[FreeFuse] Range debug block {block_idx}: invalid payload type={type(per_block)}")
                    continue

                present = [name for name in concept_names if name in per_block]
                missing = [name for name in concept_names if name not in per_block]
                print(
                    f"[FreeFuse] Range debug block {block_idx}: "
                    f"present={len(present)}/{len(concept_names)}, missing={missing}"
                )

                for name in present:
                    tensor = per_block.get(name)
                    if not torch.is_tensor(tensor):
                        print(
                            f"  - {name}: non-tensor value type={type(tensor)}"
                        )
                        continue
                    flat_len = int(tensor.reshape(1, -1).shape[1])
                    tmin = float(tensor.min().item()) if tensor.numel() > 0 else 0.0
                    tmax = float(tensor.max().item()) if tensor.numel() > 0 else 0.0
                    tmean = float(tensor.mean().item()) if tensor.numel() > 0 else 0.0
                    mismatch = "" if flat_len == expected_img_len else " [LEN_MISMATCH]"
                    print(
                        f"  - {name}: shape={tuple(tensor.shape)}, flat_len={flat_len}, "
                        f"min={tmin:.6f}, max={tmax:.6f}, mean={tmean:.6f}{mismatch}"
                    )
        except Exception as e:
            print(f"[FreeFuse] Range debug logging failed: {e}")

    @staticmethod
    def _extract_sim_map_len(sim_map: torch.Tensor) -> int:
        """Extract flattened image-token length from a similarity map tensor."""
        if sim_map is None or not torch.is_tensor(sim_map) or sim_map.numel() == 0:
            return 0
        if sim_map.dim() == 3:
            # (B, N, 1) or (B, 1, N)
            if sim_map.shape[-1] == 1:
                return int(sim_map.shape[1])
            if sim_map.shape[1] == 1:
                return int(sim_map.shape[2])
        if sim_map.dim() == 2:
            # (B, N)
            return int(sim_map.shape[1])
        if sim_map.dim() == 1:
            return int(sim_map.shape[0])
        return int(sim_map.reshape(1, -1).shape[1])

    def _resolve_range_voting_size(
        self,
        block_sim_maps: dict,
        concept_names: list,
        latent_h: int,
        latent_w: int,
    ) -> tuple:
        """Resolve voting spatial size from collected sim maps."""
        inferred_len = 0
        for _, per_block in block_sim_maps.items():
            if not isinstance(per_block, dict):
                continue
            # Prefer known concept ordering, then any available key.
            candidate_names = concept_names if concept_names else list(per_block.keys())
            for name in candidate_names:
                if name not in per_block:
                    continue
                inferred_len = self._extract_sim_map_len(per_block.get(name))
                if inferred_len > 0:
                    break
            if inferred_len > 0:
                break

        if inferred_len <= 0:
            inferred_len = int(latent_h * latent_w)

        vote_h, vote_w = self._infer_spatial_size_from_latent(
            seq_len=inferred_len,
            lat_h=latent_h,
            lat_w=latent_w,
        )
        if vote_h * vote_w != inferred_len:
            # Last-resort square fallback.
            side = int(round(inferred_len ** 0.5))
            if side > 0 and side * side == inferred_len:
                vote_h, vote_w = side, side
            else:
                vote_h, vote_w = latent_h, latent_w
                inferred_len = vote_h * vote_w
        return int(vote_h), int(vote_w), int(inferred_len)

    def _process_similarity_maps(self, similarity_maps, latent_size):
        """Convert similarity maps to spatial format."""
        if not similarity_maps:
            return {}
            
        result = {}
        h, w = latent_size
        img_len = h * w
        
        for name, sim_map in similarity_maps.items():
            if sim_map is None:
                continue
                
            # sim_map shape: (B, img_len, 1) or (B, img_len)
            if sim_map.dim() == 3:
                sim_map = sim_map.squeeze(-1)
            
            if sim_map.shape[-1] == img_len:
                # Take first batch, reshape to spatial
                spatial = sim_map[0].view(h, w)
                result[name] = spatial.detach()
            else:
                # Need to resize – infer (current_h, current_w) from latent aspect ratio
                current_len = sim_map.shape[-1]
                current_h, current_w = self._infer_spatial_size_from_latent(
                    current_len, h, w
                )
                
                if current_h * current_w == current_len:
                    spatial = sim_map[0].view(current_h, current_w)
                    spatial = F.interpolate(
                        spatial.unsqueeze(0).unsqueeze(0),
                        size=(h, w),
                        mode='bilinear',
                        align_corners=False
                    ).squeeze()
                    result[name] = spatial.detach()
                else:
                    print(f"[FreeFuse] Warning: Cannot reshape sim_map for {name}, len={current_len}")
                    result[name] = torch.ones(h, w, device=sim_map.device)
        
        print(f"[FreeFuse] Processed {len(result)} similarity maps to spatial format")
        return result
    
    def _create_preview(self, masks, width, height):
        """Create color-coded mask preview."""
        colors = [
            (1.0, 0.0, 0.0),   # Red
            (0.0, 1.0, 0.0),   # Green
            (0.0, 0.0, 1.0),   # Blue
            (1.0, 1.0, 0.0),   # Yellow
            (1.0, 0.0, 1.0),   # Magenta
            (0.0, 1.0, 1.0),   # Cyan
            (0.25, 0.25, 0.25),  # Gray (background)
        ]
        
        device = next(iter(masks.values())).device if masks else "cpu"
        preview = torch.zeros(3, height, width, device=device)
        
        for i, (name, mask) in enumerate(masks.items()):
            color = colors[i % len(colors)]
            
            # Handle different mask dimensions
            if mask.dim() == 2:
                m = mask.unsqueeze(0).unsqueeze(0)
            elif mask.dim() == 3:
                m = mask.unsqueeze(0)
            else:
                m = mask
            
            # Resize mask
            mask_resized = F.interpolate(
                m.float(),
                size=(height, width),
                mode='nearest'
            ).squeeze()
            
            for c in range(3):
                preview[c] += mask_resized * color[c]
        
        # Convert to ComfyUI format: (B, H, W, C)
        preview = preview.clamp(0, 1).permute(1, 2, 0).unsqueeze(0)
        
        return preview.cpu()
